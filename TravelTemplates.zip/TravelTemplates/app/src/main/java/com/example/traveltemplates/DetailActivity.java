package com.example.traveltemplates;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class DetailActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        ImageView imgDetail = findViewById(R.id.imgDetail);
        TextView tvDetailName = findViewById(R.id.tvDetailName);
        TextView tvDetailCategory = findViewById(R.id.tvDetailCategory);
        TextView tvDetailDescription = findViewById(R.id.tvDetailDescription);
        Button btnBack = findViewById(R.id.btnBack);

        // รับข้อมูลจาก Intent
        String name = getIntent().getStringExtra("animal_name");
        String category = getIntent().getStringExtra("animal_category");
        String detail = getIntent().getStringExtra("animal_detail");
        int imageResId = getIntent().getIntExtra("animal_image", 0);

        // นำข้อมูลไปแสดงบน UI
        tvDetailName.setText(name);
        tvDetailCategory.setText(category);
        tvDetailDescription.setText(detail);

        if (imageResId != 0) {
            imgDetail.setImageResource(imageResId);
        }

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(DetailActivity.this, MainActivity.class));
            }
        });
    }
}