package com.example.traveltemplates;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class AnimalDatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "animal_db.db";
    private static final int DB_VERSION = 3; // ปรับเป็นเวอร์ชัน 3 เพื่อให้ลบตารางเก่าแล้วสร้างโครงสร้างใหม่
    public static final String TABLE_NAME = "animals";
    public static final String COL_ID = "id";
    public static final String COL_NAME_TH = "name_th";
    public static final String COL_NAME_EN = "name_en";
    public static final String COL_CATEGORY = "category";
    public static final String COL_IMAGE = "image_name";
    public static final String COL_DETAIL = "detail";

    public AnimalDatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_NAME + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_NAME_TH + " TEXT, " +
                COL_NAME_EN + " TEXT, " +
                COL_CATEGORY + " TEXT, " +
                COL_IMAGE + " TEXT, " +
                COL_DETAIL + " TEXT)";
        db.execSQL(createTable);

        insertInitialData(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    private void insertInitialData(SQLiteDatabase db) {
        // ใส่ข้อมูลให้ครบ 5 ช่องทุกรายการ (ชื่อไทย, ชื่ออังกฤษ, ประเภท, ชื่อรูปภาพ, รายละเอียด)
        String[][] animals = {
                {"สิงโต", "Lion", "สัตว์เลี้ยงลูกด้วยนม", "lion", "พบได้ในทวีปแอฟริกาและเอเชีย"},
                {"เสือ", "Tiger", "สัตว์เลี้ยงลูกด้วยนม", "tiger", "สัตว์นักล่าตระกูลแมวขนาดใหญ่ที่สุด"},
                {"ช้าง", "Elephant", "สัตว์เลี้ยงลูกด้วยนม", "elephant", "สัตว์บกที่มีขนาดใหญ่ที่สุด"},
                {"สุนัข", "Dog", "สัตว์เลี้ยงลูกด้วยนม", "dog", "สัตว์เลี้ยงที่ซื่อสัตย์ของมนุษย์"},
                {"แมว", "Cat", "สัตว์เลี้ยงลูกด้วยนม", "cat", "สัตว์เลี้ยงยอดนิยมขนาดเล็ก"},
                {"นกอินทรี", "Eagle", "สัตว์ปีก", "eagle", "สัตว์ปีกสายตากว้างไกลนักล่า"},
                {"เพนกวิน", "Penguin", "สัตว์ปีก", "penguin", "นกบินไม่ได้ที่อาศัยในเขตหนาว"},
                {"จระเข้", "Crocodile", "สัตว์เลื้อยคลาน", "crocodile", "สัตว์เลื้อยคลานครึ่งบกครึ่งน้ำขนาดใหญ่"},
                {"เต่า", "Turtle", "สัตว์เลื้อยคลาน", "turtle", "สัตว์เลื้อยคลานที่มีกระดองคุ้มกัน"},
                {"ฉลาม", "Shark", "สัตว์น้ำ", "shark", "นักล่าระดับบนสุดแห่งท้องทะเล"}
        };

        for (String[] animal : animals) {
            ContentValues cv = new ContentValues();
            cv.put(COL_NAME_TH, animal[0]);
            cv.put(COL_NAME_EN, animal[1]);
            cv.put(COL_CATEGORY, animal[2]);
            cv.put(COL_IMAGE, animal[3]);
            cv.put(COL_DETAIL, animal[4]);
            db.insert(TABLE_NAME, null, cv);
        }
    }

    public Cursor searchAnimals(String keyword) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_NAME + " WHERE " +
                COL_NAME_TH + " LIKE ? OR " +
                COL_NAME_EN + " LIKE ? OR " +
                COL_CATEGORY + " LIKE ?";
        String searchPattern = "%" + keyword + "%";
        return db.rawQuery(query, new String[]{searchPattern, searchPattern, searchPattern});
    }

    public Cursor getAllAnimals() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
    }
}