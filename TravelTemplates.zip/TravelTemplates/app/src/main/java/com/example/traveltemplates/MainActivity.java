package com.example.traveltemplates;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private EditText etSearch;
    private ListView listViewAnimals;
    private AnimalDatabaseHelper dbHelper;
    private List<Map<String, Object>> animalList; // ดึงออกมาเป็นตัวแปรระดับคลาส

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etSearch = findViewById(R.id.etSearch);
        listViewAnimals = findViewById(R.id.listViewAnimals);
        dbHelper = new AnimalDatabaseHelper(this);

        displayAnimals("");

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                displayAnimals(s.toString().trim());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        listViewAnimals.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Map<String, Object> selectedAnimal = animalList.get(position);

                Intent intent = new Intent(MainActivity.this, DetailActivity.class);
                intent.putExtra("animal_name", selectedAnimal.get("name").toString());
                intent.putExtra("animal_category", selectedAnimal.get("category").toString());
                intent.putExtra("animal_detail", selectedAnimal.get("detail").toString());
                intent.putExtra("animal_image", (int) selectedAnimal.get("image"));

                startActivity(intent);
            }
        });
        // --------------------------------------------------------------------------------------
    }

    private void displayAnimals(String keyword) {
        Cursor cursor = keyword.isEmpty() ? dbHelper.getAllAnimals() : dbHelper.searchAnimals(keyword);

        animalList = new ArrayList<>(); // ใช้ตัวแปรระดับคลาสที่ประกาศไว้ด้านบน

        if (cursor != null && cursor.moveToFirst()) {
            do {
                String nameTh = cursor.getString(cursor.getColumnIndexOrThrow(AnimalDatabaseHelper.COL_NAME_TH));
                String nameEn = cursor.getString(cursor.getColumnIndexOrThrow(AnimalDatabaseHelper.COL_NAME_EN));
                String category = cursor.getString(cursor.getColumnIndexOrThrow(AnimalDatabaseHelper.COL_CATEGORY));
                String imageName = cursor.getString(cursor.getColumnIndexOrThrow(AnimalDatabaseHelper.COL_IMAGE));
                String detail = cursor.getString(cursor.getColumnIndexOrThrow(AnimalDatabaseHelper.COL_DETAIL));

                int imageResId = getResources().getIdentifier(imageName, "drawable", getPackageName());
                if (imageResId == 0) {
                    imageResId = android.R.drawable.ic_menu_gallery;
                }

                Map<String, Object> map = new HashMap<>();
                map.put("name", nameTh + " (" + nameEn + ")");
                map.put("category", "ประเภท: " + category);
                map.put("detail", detail);
                map.put("image", imageResId);
                animalList.add(map);
            } while (cursor.moveToNext());
            cursor.close();
        }

        SimpleAdapter adapter = new SimpleAdapter(
                this,
                animalList,
                R.layout.item_animal,
                new String[]{"name", "category", "detail", "image"},
                new int[]{R.id.tvAnimalName, R.id.tvAnimalCategory, R.id.tvAnimalDetail, R.id.imgAnimal}
        );

        listViewAnimals.setAdapter(adapter);
    }
}